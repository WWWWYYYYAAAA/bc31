#ifndef _PAGE6_H_
#define _PAGE6_H_

int page6();

#endif
#ifndef _PLAYER_H_
#define _PLAYER_H_

int play(char * prjdir);
int playtofile(char * prjdir);

#endif
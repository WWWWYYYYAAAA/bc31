#ifndef _PAGE234_H_
#define _PAGE234_H_

//int page2();
//int page3();
//int page4();
//int example(float AR, float BR, int Xoffset,int Zoffset,int Yoffset, int sizeP, int sizeB);
int page234(char *prjdir);

#endif
#ifndef _ERROR_H_
#define _ERROR_H_

int error(int signal);

#endif
#ifndef _PRINTG_h_
#define _PRINTG_h_

int printg(int x0, int y0, int color, const char *str, ...);
int printg_cn(int x0, int y0, int color, int style[5], const char *str, ...);

#endif

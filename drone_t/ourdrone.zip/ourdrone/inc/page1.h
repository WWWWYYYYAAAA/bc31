#ifndef _PAGE1_H_
#define _PAGE1_H_

int page1();

#endif
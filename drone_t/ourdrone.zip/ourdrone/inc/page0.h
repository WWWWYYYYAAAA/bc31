#ifndef _PAGE0_H_
#define _PAGE0_H_

int page0();
int initialization();

#endif